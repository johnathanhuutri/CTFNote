#!/bin/sh

gcc run.c -o run
patchelf --replace-needed libc.so.6 ./libc-2.23.so run
patchelf --set-interpreter ./ld-2.23.so run