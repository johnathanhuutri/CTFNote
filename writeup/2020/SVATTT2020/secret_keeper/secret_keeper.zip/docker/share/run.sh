#!/bin/sh

cd /home/user
./secret_keeper