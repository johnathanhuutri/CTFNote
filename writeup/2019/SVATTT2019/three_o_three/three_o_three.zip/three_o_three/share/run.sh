#!/bin/sh

cd /home/user
./three_o_three