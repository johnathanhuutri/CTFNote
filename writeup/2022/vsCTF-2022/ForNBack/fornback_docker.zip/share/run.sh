#!/bin/sh

cd /home/Fornback
./fornback