#!/bin/sh

cd /home/orangeworld
./ezorange