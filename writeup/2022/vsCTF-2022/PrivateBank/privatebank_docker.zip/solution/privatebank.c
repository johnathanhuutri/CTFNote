// gcc -m32 -no-pie -z relro -z now -o privatebank privatebank.c

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char flag[] = "vsctf{tH1S_!s_F4k3_fL4G_F@r_Sur3_0f19014e935cee6f56b59b51f554656e}";

void init()
{
	setbuf(stdin, NULL);
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
}

int main()
{
	FILE *fp;
	char key[0x10], number[13], *flagp;

	init();
	flagp = malloc(0x100);
	fp = fopen("flag.txt", "r");
	if (fp==NULL)
	{
		puts("File not found!");
		return -1;
	}
	fscanf(fp, "%s", flagp);
	fclose(fp);
	fp = NULL;
	flagp = NULL;

	puts("Welcome to PRIVATE bank!");
	puts("Please enter the following detail to unlock your cabinet.");
	printf("Hint: %p\n", &system);
	puts("--------------------------------");
	
	printf("Cabinet number: ");
	read(0, number, 13);
	if (atoi(number) == 0)
	{
		puts("Invalid number!");
		exit(-1);
	}	
	printf("Your cabinet number: ");
	printf(number);
	puts("--------------------------------");

	printf("Key: ");
	read(0, key, 0x10);
	printf("Your key: ");
	printf(key);
	if (!strncmp(number, "3405691582", 10) && !strncmp(key, "4Dm1N", 5))
	{
		printf("You got ");
		puts(flag);
	}
	else
		puts("Cabinet number or key is incorrect!");

	exit(0);
}