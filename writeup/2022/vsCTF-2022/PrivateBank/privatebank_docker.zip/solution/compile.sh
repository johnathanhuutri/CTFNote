#!/bin/sh

# gcc -no-pie -z relro -z now -o privatebank privatebank.c
gcc -z relro -z now -o privatebank privatebank.c
patchelf --replace-needed libc.so.6 ./libc-2.34.so privatebank
patchelf --set-interpreter ./ld-2.34.so privatebank