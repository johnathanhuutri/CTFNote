#!/bin/sh

cd /home/user/
./calert