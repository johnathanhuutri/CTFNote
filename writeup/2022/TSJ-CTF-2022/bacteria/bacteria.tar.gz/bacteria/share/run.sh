#!/bin/sh

exec 2>/dev/null
timeout 60 env -i /home/bacteria/bacteria
