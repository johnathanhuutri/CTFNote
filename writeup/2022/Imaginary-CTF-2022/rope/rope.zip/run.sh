#!/bin/bash

LD_PRELOAD=./libc-2.23.so ./ld-2.23.so ./vuln
